const Profile = () => {
  <title>Profile</title>
  return (
    <>
      <nav className="bg-white p-8">
        <div className="container mx-10 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Thebausffs</h1>
          <div className="flex space-x-6">
            <a href="#" className="bg-red-200 text-black font-semibold px-4 py-2 rounded-full">
              Home
            </a>
            <a href="#" className="text-black px-4 py-2 font-semibold">About me</a>
            <a href="#" className="text-black px-4 py-2 font-semibold">Gallery</a>
          </div>

          <a href="#" className="bg-red-900 text-white font-semibold px-4 py-2 rounded-full">
            Contact
          </a>
        </div>
      </nav>
      <section className="container mx-auto flex flex-col md:flex-row items-center mt-16 px-6">
        <div className="w-full md:w-1/2 text-center md:text-left">
          <h2 className="text-lg font-semibold">Hello It's me</h2>
          <h1 className="text-4xl font-bold">Thebausffs</h1>
          <p className="mt-2 text-gray-600">Simon "Baus" Hofverberg is a League of Legends esports player, currently top laner for Los Ratones. inventor of wpgg </p>
          <div className="flex justify-center md:justify-start space-x-4 mt-4 ">
            <img src="public/ig.png" alt="ig" className="w-10"/>
            <img src="public/fb.png" alt="fb" className="w-10"/>
            <img src="public/email.jpg" alt="email" className="w-10"/>
          </div>
          <button className="mt-6 bg-red-900 text-white px-6 py-3 rounded-full">My Portfolio</button>
        </div>

        <div className="w-full md:w-1/2 flex justify-center">
          <img src="public/Baus.png" alt="Baus" className="w-100"/>
        </div>
      </section>
      <section className="container mx-auto flex flex-col md:flex-row items-center mt-32 px-6">
        <div className="w-full md:w-1/2 flex justify-center">
          <img src="public/bausnaked.jpg" alt="bausnaked" className="w-70"/>
        </div>

        <div className="w-full md:w-1/2 text-center md:text-left">
          <h2 className="text-3xl font-bold">About Me</h2>
          <p className="text-gray-700 mt-4">Esport player</p>
          <p className="text-gray-700 mt-4">
          TheBausffs is a high-elo League of Legends streamer and content creator, best known for his unique "inting Sion" playstyle. With an aggressive, high-risk approach to the game, he has earned a reputation for strategic tower-diving, fearless split pushing, and making unconventional plays that somehow work. His unorthodox strategies, combined with his entertaining personality, have made him a fan favorite in the League of Legends community.
          </p>
          <button className="mt-6 bg-red-900 text-white px-6 py-3 rounded-full">Read More</button>
        </div>
      </section>

      <section className="container mx-auto mt-32 px-6">
        <h2 className="text-3xl font-bold text-center">Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 mt-8">
          <img src="public/bauslol.jpg" alt="baus1" className="rounded-lg"/>
          <img src="public/bausfunny.jpg" alt="baus2" className="rounded-lg"/>
          <img src="public/bausbeard.jpg" alt="baus3" className="rounded-lg"/>
          <img src="public/baushater.jpeg" alt="baus4" className="rounded-lg"/>
          <img src="public/bausbread.jpg" alt="baus5" className="rounded-lg"/>
          <img src="public/baussit.jpg" alt="baus6" className="w-120 rounded-lg"/>
        </div>
      </section>
    </>
  );
};
export default Profile;
